﻿using Burger_Project.Models;

namespace Burger_Project.Services
{
    public interface IRegisterS
    {
        void RegisterUser(Register user);
    }
}
